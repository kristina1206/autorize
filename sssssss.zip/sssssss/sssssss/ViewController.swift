//
//  ViewController.swift
//  sssssss
//
//  Created by слепцова кристина on 05.09.2022.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var registr: UILabel!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBAction func gotovo(_ sender: Any) {
        if(email.text=="kristina@mail.ru") && (password.text=="shp-2002"){
            performSegue(withIdentifier: "view", sender: nil)
        }
        else {
            registr.text = "Ошибка в логине или пароле"
            registr.textColor = UIColor.red
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

